# Just initiate a plain shutdown.
/usr/sbin/shutdown -h now "Power button pressed or power-button signal received from mainboard...\n...shutting down now!"
